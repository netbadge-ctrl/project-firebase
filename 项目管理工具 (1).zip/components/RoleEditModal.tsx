import React, { useState, useMemo, useEffect, useRef, useLayoutEffect } from 'react';
import ReactDOM from 'react-dom';
import { Project, User, Role, TeamMember, ProjectRoleKey } from '../types';
import { IconX, IconTrash, IconPlus, IconLink, IconSearch } from './Icons';
import { DateRangePicker } from './DateRangePicker';
import { fuzzySearch } from '../utils';
import { SearchableSingleSelectDropdown } from './SearchableSingleSelectDropdown';

interface RoleEditModalProps {
  project: Project;
  roleKey: ProjectRoleKey;
  roleName: string;
  allUsers: User[];
  onClose: () => void;
  onSave: (projectId: string, roleKey: ProjectRoleKey, newRole: Role) => void;
}

type TeamMemberWithState = TeamMember & { useSharedSchedule: boolean; _tempId: string };

export const RoleEditModal: React.FC<RoleEditModalProps> = ({ project, roleKey, roleName, allUsers, onClose, onSave }) => {
  const [currentTeam, setCurrentTeam] = useState<TeamMemberWithState[]>(
    (project[roleKey] || []).map((m, index) => ({ 
        ...m, 
        useSharedSchedule: m.useSharedSchedule ?? false,
        _tempId: `member_${index}_${Date.now()}`
    }))
  );
  
  const [isAddingMember, setIsAddingMember] = useState(false);
  const [addMemberSearch, setAddMemberSearch] = useState('');
  const addMemberContainerRef = useRef<HTMLDivElement>(null);
  const addMemberSearchInputRef = useRef<HTMLInputElement>(null);
  const addMemberTriggerRef = useRef<HTMLButtonElement>(null);
  const addMemberMenuRef = useRef<HTMLDivElement>(null);
  const [addMemberMenuStyle, setAddMemberMenuStyle] = useState<React.CSSProperties>({});

  const availableUsers = useMemo(() => {
    const teamUserIds = new Set(currentTeam.map(m => m.userId));
    const filtered = allUsers.filter(u => !teamUserIds.has(u.id));
    if (!addMemberSearch) return filtered;
    return filtered.filter(u => fuzzySearch(addMemberSearch, u.name));
  }, [allUsers, currentTeam, addMemberSearch]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (addMemberContainerRef.current && !addMemberContainerRef.current.contains(event.target as Node) &&
          addMemberMenuRef.current && !addMemberMenuRef.current.contains(event.target as Node)) {
        setIsAddingMember(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  
  useEffect(() => {
    if (isAddingMember) {
        setAddMemberSearch('');
        setTimeout(() => addMemberSearchInputRef.current?.focus(), 100);
    }
  }, [isAddingMember]);

  useLayoutEffect(() => {
    if (!isAddingMember) {
        setAddMemberMenuStyle(s => ({ ...s, opacity: 0, pointerEvents: 'none' }));
        return;
    }
    const triggerEl = addMemberTriggerRef.current;
    const menuEl = addMemberMenuRef.current;
    if (!triggerEl || !menuEl) return;

    const calculatePosition = () => {
        const rect = triggerEl.getBoundingClientRect();
        const menuHeight = menuEl.offsetHeight;
        const gap = 8;
        
        let top = rect.top - menuHeight - gap;
        if (top < 0) { // Not enough space on top, open below
            top = rect.bottom + gap;
        }
        
        setAddMemberMenuStyle({
            position: 'fixed',
            top: `${top}px`,
            left: `${rect.left}px`,
            width: `${rect.width}px`,
            zIndex: 60,
            opacity: 1,
            transition: 'opacity 150ms ease-in-out',
            pointerEvents: 'auto',
        });
    };
    
    calculatePosition();
    window.addEventListener('scroll', calculatePosition, true);
    window.addEventListener('resize', calculatePosition);
    return () => {
        window.removeEventListener('scroll', calculatePosition, true);
        window.removeEventListener('resize', calculatePosition);
    };
}, [isAddingMember]);


  const handleAddMember = (userId: string) => {
    if (userId) {
      const isFirstMember = currentTeam.length === 0;
      const newMember: TeamMemberWithState = {
        userId,
        startDate: new Date().toISOString().split('T')[0],
        endDate: '',
        useSharedSchedule: !isFirstMember,
        _tempId: `member_new_${Date.now()}`
      };
      setCurrentTeam(prev => [...prev, newMember]);
      setIsAddingMember(false);
    }
  };

  const handleUpdateMember = (tempId: string, newUserId: string) => {
    setCurrentTeam(prevTeam => prevTeam.map(m => m._tempId === tempId ? { ...m, userId: newUserId } : m));
  };

  const handleRemoveMember = (tempId: string) => {
    setCurrentTeam(prev => prev.filter(m => m._tempId !== tempId));
  };
  
  const handleIndividualDateChange = (tempId: string, startDate: string, endDate: string) => {
    setCurrentTeam(prev => prev.map(m => m._tempId === tempId ? {...m, startDate, endDate } : m));
  };
  
  const handleToggleSharedSchedule = (tempId: string) => {
    setCurrentTeam(prev => prev.map(m => m._tempId === tempId ? { ...m, useSharedSchedule: !m.useSharedSchedule } : m));
  };
  
  const handleSave = () => {
    const masterSchedule = currentTeam.length > 0 
        ? { startDate: currentTeam[0].startDate, endDate: currentTeam[0].endDate }
        : { startDate: '', endDate: '' };

    const finalTeam = currentTeam.map((member, index) => {
        const { _tempId, ...memberData } = member;
        if (index > 0 && memberData.useSharedSchedule) {
            memberData.startDate = masterSchedule.startDate;
            memberData.endDate = masterSchedule.endDate;
        }
        return memberData as TeamMember;
    });

    const seenUserIds = new Set();
    const uniqueFinalTeam = finalTeam.filter(member => {
        if(seenUserIds.has(member.userId)) return false;
        seenUserIds.add(member.userId);
        return true;
    });

    onSave(project.id, roleKey, uniqueFinalTeam);
  };

  const ringClass = "focus:ring-2 focus:ring-[#6C63FF]";
  
  const firstMember = currentTeam.length > 0 ? currentTeam[0] : null;
  const firstUser = firstMember ? allUsers.find(u => u.id === firstMember.userId) : null;
  const firstMemberScheduleText = firstMember?.startDate && firstMember?.endDate ? `${firstMember.startDate} ~ ${firstMember.endDate}` : "请为第一位成员设置排期";

  const addMemberMenu = (
    <div ref={addMemberMenuRef} style={addMemberMenuStyle} className="bg-white dark:bg-[#2d2d2d] border border-gray-200 dark:border-[#4a4a4a] rounded-lg shadow-xl flex flex-col">
       <div className="p-2 border-b border-gray-200 dark:border-[#4a4a4a]">
            <div className="relative">
               <IconSearch className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
               <input
                 ref={addMemberSearchInputRef}
                 type="text"
                 placeholder="搜索用户..."
                 value={addMemberSearch}
                 onChange={(e) => setAddMemberSearch(e.target.value)}
                 className="bg-gray-50 dark:bg-[#232323] border border-gray-300 dark:border-[#4a4a4a] rounded-md pl-8 pr-2 py-1.5 w-full text-sm text-gray-900 dark:text-gray-200 focus:outline-none focus:ring-1 focus:ring-[#6C63FF]"
               />
            </div>
        </div>
       <ul className="p-1 flex-grow overflow-y-auto max-h-48">
          {availableUsers.map(user => (
            <li key={user.id}>
                <button onClick={() => handleAddMember(user.id)} className="w-full text-left px-3 py-2 text-sm text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-100 dark:hover:bg-[#3a3a3a]">
                    {user.name}
                </button>
            </li>
          ))}
          {availableUsers.length === 0 && (
             <li className="px-3 py-2 text-sm text-gray-500 text-center">
                 {addMemberSearch ? '无匹配用户' : '所有用户都已添加'}
             </li>
          )}
       </ul>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <div className="bg-white dark:bg-[#232323] border border-gray-200 dark:border-[#363636] rounded-xl w-full max-w-3xl text-gray-900 dark:text-white shadow-lg flex flex-col max-h-[90vh]">
        <div className="flex-shrink-0 flex justify-between items-center p-4 border-b border-gray-200 dark:border-[#363636]">
          <h2 id="modal-title" className="text-xl font-bold">编辑{roleName}</h2>
          <button onClick={onClose} className="p-1 rounded-full text-gray-500 hover:bg-gray-200 dark:text-gray-400 dark:hover:bg-gray-700" aria-label="关闭">
            <IconX className="w-6 h-6" />
          </button>
        </div>
        
        <div className="flex-grow p-6 overflow-y-auto space-y-6">
            {/* Team Members Section */}
            <div>
                <div className="flex justify-between items-center mb-3">
                    <h3 className="font-semibold text-gray-900 dark:text-white">团队成员</h3>
                    <p className="text-sm text-gray-400 dark:text-gray-500">可自由增减人数</p>
                </div>
                <div className="space-y-3">
                    {currentTeam.map((member, index) => {
                        const user = allUsers.find(u => u.id === member.userId);
                        if (!user) return null;

                        const memberOptions = [
                            { value: user.id, label: user.name },
                            ...availableUsers.map(u => ({ value: u.id, label: u.name }))
                        ];

                        return (
                            <div key={member._tempId} className="bg-gray-100 dark:bg-[#2d2d2d] p-4 rounded-lg space-y-3">
                                <div className="flex justify-between items-center">
                                    <h4 className="font-semibold text-gray-700 dark:text-gray-300">
                                      成员 {index + 1}
                                      {index === 0 && <span className="text-xs font-normal text-gray-500 ml-1">(排期负责人)</span>}
                                    </h4>
                                    <div className="flex items-center gap-3">
                                        {index > 0 && firstUser && (
                                            <label className="flex items-center gap-2 text-sm cursor-pointer">
                                                <input type="checkbox" checked={member.useSharedSchedule} onChange={() => handleToggleSharedSchedule(member._tempId)} className={`h-4 w-4 rounded bg-gray-300 dark:bg-gray-700 border-gray-400 dark:border-gray-600 text-[#6C63FF] ${ringClass}`} />
                                                与 {firstUser.name} 排期相同
                                            </label>
                                        )}
                                        <button onClick={() => handleRemoveMember(member._tempId)} className="p-1 text-red-500/80 hover:text-red-500 hover:bg-red-500/10 rounded-full" aria-label={`移除 ${user.name}`}>
                                            <IconTrash className="w-5 h-5" />
                                        </button>
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                                    <div>
                                        <label className="text-sm text-gray-500 dark:text-gray-400 mb-1 block">姓名</label>
                                        <SearchableSingleSelectDropdown
                                            value={member.userId}
                                            onChange={(newUserId) => handleUpdateMember(member._tempId, newUserId)}
                                            options={memberOptions}
                                            placeholder="选择成员"
                                        />
                                    </div>
                                    <div>
                                        { index === 0 ? (
                                             <div>
                                                <label className="text-sm text-gray-500 dark:text-gray-400 mb-1 block">排期时间范围</label>
                                                <DateRangePicker
                                                    startDate={member.startDate}
                                                    endDate={member.endDate}
                                                    onSelectRange={(start, end) => handleIndividualDateChange(member._tempId, start, end)}
                                                />
                                            </div>
                                        ) : member.useSharedSchedule ? (
                                            <div className="h-full flex items-center bg-[#6C63FF]/10 border border-[#6C63FF]/20 text-[#6C63FF] dark:text-[#A29DFF] rounded-md px-3 py-1.5">
                                                <IconLink className="w-5 h-5 mr-2 flex-shrink-0" />
                                                <span className="text-sm font-semibold truncate">
                                                    {firstMemberScheduleText}
                                                </span>
                                            </div>
                                        ) : (
                                            <div>
                                                <label className="text-sm text-gray-500 dark:text-gray-400 mb-1 block">个人排期时间范围</label>
                                                <DateRangePicker
                                                    startDate={member.startDate}
                                                    endDate={member.endDate}
                                                    onSelectRange={(start, end) => handleIndividualDateChange(member._tempId, start, end)}
                                                />
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
            
            {/* Add Member Button */}
            <div ref={addMemberContainerRef}>
                <button
                    ref={addMemberTriggerRef}
                    onClick={() => setIsAddingMember(p => !p)}
                    className="w-full border-2 border-dashed border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500 rounded-lg py-3 flex items-center justify-center gap-2 text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors"
                >
                    <IconPlus className="w-5 h-5" />
                    <span className="font-semibold">添加成员</span>
                </button>
                {isAddingMember && ReactDOM.createPortal(addMemberMenu, document.body)}
            </div>
        </div>

        <div className="flex-shrink-0 flex justify-end gap-4 p-4 border-t border-gray-200 dark:border-[#363636]">
          <button onClick={onClose} className="px-4 py-2 bg-white dark:bg-[#3a3a3a] border border-gray-300 dark:border-[#4a4a4a] rounded-lg font-semibold text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">取消</button>
          <button onClick={handleSave} className="px-4 py-2 bg-[#6C63FF] text-white rounded-lg font-semibold text-sm hover:bg-[#5a52d9] transition-colors">保存更改</button>
        </div>
      </div>
    </div>
  );
};
