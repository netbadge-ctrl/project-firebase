import { PROJECTS, OKR_SETS, ALL_USERS } from './constants';
import { Project, OKR, User, OkrSet } from './types';

// 创建可变副本以模拟数据库
let projectsDB: Project[] = JSON.parse(JSON.stringify(PROJECTS));
let okrSetsDB: OkrSet[] = JSON.parse(JSON.stringify(OKR_SETS));
const usersDB: User[] = JSON.parse(JSON.stringify(ALL_USERS));

const FAKE_DELAY = 400;

const simulateRequest = <T>(data: T): Promise<T> => {
    return new Promise(resolve => {
        setTimeout(() => {
            // 返回数据的深拷贝以防止意外的直接修改
            resolve(JSON.parse(JSON.stringify(data)));
        }, FAKE_DELAY);
    });
};

export const api = {
    fetchProjects: (): Promise<Project[]> => {
        return simulateRequest(projectsDB);
    },
    
    fetchOkrSets: (): Promise<OkrSet[]> => {
        return simulateRequest(okrSetsDB);
    },
    
    fetchUsers: (): Promise<User[]> => {
        return simulateRequest(usersDB);
    },

    login: (userId: string): Promise<User> => {
        const user = usersDB.find(u => u.id === userId);
        if (user) {
            return simulateRequest(user);
        }
        return Promise.reject(new Error('User not found'));
    },

    createProject: (projectData: Project): Promise<Project> => {
        const { isNew, ...restOfData } = projectData;
        const newProject: Project = {
            ...restOfData,
            id: `p${Date.now()}`, // 生成一个唯一的永久ID
        };
        projectsDB = [newProject, ...projectsDB];
        return simulateRequest(newProject);
    },
    
    updateProject: (projectId: string, updates: Partial<Project>): Promise<Project> => {
        let updatedProject: Project | undefined;
        projectsDB = projectsDB.map(p => {
            if (p.id === projectId) {
                updatedProject = { ...p, ...updates };
                return updatedProject;
            }
            return p;
        });

        if (updatedProject) {
            return simulateRequest(updatedProject);
        }
        return Promise.reject(new Error('Project not found'));
    },

    deleteProject: (projectId: string): Promise<{ success: boolean }> => {
        const initialLength = projectsDB.length;
        projectsDB = projectsDB.filter(p => p.id !== projectId);
        if (projectsDB.length < initialLength) {
            return simulateRequest({ success: true });
        }
        return Promise.reject(new Error('Project not found'));
    },
    
    updateOkrSet: (updatedSet: OkrSet): Promise<OkrSet> => {
        let found = false;
        okrSetsDB = okrSetsDB.map(set => {
            if (set.periodId === updatedSet.periodId) {
                found = true;
                return updatedSet;
            }
            return set;
        });
        if (found) {
            return simulateRequest(updatedSet);
        }
        return Promise.reject(new Error('OKR set not found for the given periodId'));
    },

    createOkrSet: (periodId: string, periodName: string): Promise<OkrSet> => {
        const existing = okrSetsDB.find(s => s.periodId === periodId);
        if (existing) {
            return Promise.reject(new Error('OKR set for this period already exists'));
        }
        const newSet: OkrSet = {
            periodId,
            periodName,
            okrs: [],
        };
        okrSetsDB = [...okrSetsDB, newSet].sort((a,b) => b.periodId.localeCompare(a.periodId));
        return simulateRequest(newSet);
    },
    
    performWeeklyRollover: (): Promise<{ updatedProjectIds: string[] }> => {
        const updatedProjectIds: string[] = [];
        projectsDB = projectsDB.map(p => {
            // Only move if there is a weekly update to prevent overwriting last week's with empty string
            if (p.weeklyUpdate && p.weeklyUpdate.trim() !== '') {
                updatedProjectIds.push(p.id);
                return {
                    ...p,
                    lastWeekUpdate: p.weeklyUpdate,
                    weeklyUpdate: '' // Clear current week's update
                };
            }
            return p;
        });
        return simulateRequest({ updatedProjectIds });
    }
};