import React, { useState, useEffect, useCallback, useContext, createContext } from 'react';
import { api } from '../api';
import { User } from '../types';

interface AuthContextType {
    user: User | null;
    login: (userId: string) => Promise<void>;
    logout: () => void;
    isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
    const [user, setUser] = useState<User | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const autoLogin = async () => {
            setIsLoading(true);
            try {
                const users = await api.fetchUsers();
                if (users && users.length > 0) {
                    setUser(users[0]); // Automatically "log in" as the first user.
                } else {
                    console.error("No users available to auto-login.");
                }
            } catch (error) {
                console.error("Auto-login failed", error);
            } finally {
                setIsLoading(false);
            }
        };
        autoLogin();
    }, []);

    const login = useCallback(async (userId: string) => {
        // This function could be used for user switching in the future.
        setIsLoading(true);
        try {
            const loggedInUser = await api.login(userId);
            setUser(loggedInUser);
        } catch (error) {
            console.error("Switching user failed", error);
            throw error;
        } finally {
            setIsLoading(false);
        }
    }, []);

    const logout = useCallback(() => {
        // This is now a no-op as there is no login screen to go back to.
    }, []);

    return (
        <AuthContext.Provider value={{ user, login, logout, isLoading }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};