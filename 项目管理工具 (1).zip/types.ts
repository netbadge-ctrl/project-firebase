// A global user pool
export interface User {
  id: string;
  name: string;
  avatarUrl: string;
}

// A team member is a user with a specific schedule for a project
export interface TeamMember {
  userId: string;
  startDate: string;
  endDate: string;
  useSharedSchedule?: boolean;
}

// Each role is an array of team members
export type Role = TeamMember[];

export enum ProjectStatus {
  NotStarted = '未开始',
  Discussion = '需求讨论',
  RequirementsDone = '需求完成',
  ReviewDone = '待开发',
  InProgress = '开发中',
  DevDone = '待测试',
  Testing = '测试中',
  TestDone = '测试完成待上线',
  Launched = '已上线',
}

export enum Priority {
    DeptOKR = '部门OKR相关',
    PersonalOKR = '个人OKR相关',
    Urgent = '临时重要需求',
    Routine = '日常需求',
}

export interface KeyResult {
  id: string;
  description: string;
}

export interface OKR {
  id:string;
  objective: string;
  keyResults: KeyResult[];
}

export interface OkrSet {
  periodId: string; // e.g., "2025-H2"
  periodName: string; // e.g., "2025下半年"
  okrs: OKR[];
}

export interface Comment {
  id: string;
  userId: string;
  text: string;
  createdAt: string;
  mentions?: string[];
}

export interface ChangeLogEntry {
  id: string;
  userId: string;
  field: string;
  oldValue: string;
  newValue: string;
  changedAt: string;
}

export interface Project {
  id: string;
  name: string;
  priority: Priority;
  businessProblem: string;
  keyResultIds: string[];
  weeklyUpdate: string;
  lastWeekUpdate: string;
  status: ProjectStatus;
  productManagers: Role;
  backendDevelopers: Role;
  frontendDevelopers: Role;
  qaTesters: Role;
  proposalDate: string;
  launchDate: string;
  followers: string[];
  comments: Comment[];
  changeLog: ChangeLogEntry[];
  isNew?: boolean;
}

export type ProjectRoleKey = keyof Pick<Project, 'productManagers' | 'backendDevelopers' | 'frontendDevelopers' | 'qaTesters'>;