import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { AuthProvider, useAuth } from './context/auth-context';
import { ThemeProvider } from './context/theme-context';
import { LoadingSpinner } from './components/LoadingSpinner';

const AppGate: React.FC = () => {
    const { user, logout, isLoading } = useAuth();

    if (isLoading) {
        return <LoadingSpinner />;
    }

    if (!user) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-[#1A1A1A] text-red-500">
                错误：无法加载用户数据，应用无法启动。
            </div>
        );
    }

    return <App currentUser={user} onLogout={logout} />;
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <ThemeProvider>
      <AuthProvider>
        <AppGate />
      </AuthProvider>
    </ThemeProvider>
  </React.StrictMode>
);